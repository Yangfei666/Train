<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'tbh1832901';
$cfg_dbuser = 'tbh1832901';
$cfg_dbpwd = '0C08BCE7035387';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>